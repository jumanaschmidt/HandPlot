// Include only morph::randSingle.h from rng.h
#pragma once
#define RANDSINGLE 1
#define NO_RANDDOUBLE 1
#include <morph/rng.h>
