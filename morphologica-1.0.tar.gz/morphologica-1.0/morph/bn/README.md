Boolean net clases in the morph::bn namespace
