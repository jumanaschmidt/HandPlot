This directory contains neural network classes in the morph::nn namespace.
