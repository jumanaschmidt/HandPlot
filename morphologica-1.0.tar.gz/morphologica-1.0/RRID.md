# morphologica RRID

morphologica has a Research Resource Identifier (RRID), which is ***SCR_018813***.

The RRID can be used to reference the use of morphologica in a publication.

You can search for the associated record at https://scicrunch.org/resources
