# Schakenberg reaction diffusion system

Non standalone version of the Schakenberg RD system.