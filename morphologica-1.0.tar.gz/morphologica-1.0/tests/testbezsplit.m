figure(1)
clf
plot (oc(:,1), oc(:,2), 'bo');
hold on;
plot (c1(:,1), c1(:,2), 'ro');
plot (c2(:,1), c2(:,2), 'go');

plot (cv(:,1), cv(:,2), 'b-');
plot (cv1(:,1), cv1(:,2), 'r-');
plot (cv2(:,1), cv2(:,2), 'g-');
